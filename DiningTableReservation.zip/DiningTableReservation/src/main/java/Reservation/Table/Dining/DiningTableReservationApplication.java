package Reservation.Table.Dining;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiningTableReservationApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiningTableReservationApplication.class, args);
	}

}
