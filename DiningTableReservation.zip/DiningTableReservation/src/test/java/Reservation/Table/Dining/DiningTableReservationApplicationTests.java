package Reservation.Table.Dining;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiningTableReservationApplicationTests {

	@Test
	void contextLoads() {
	}

}
